history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls -l
hostnamectl set-hostname TPServer
vim /etc/hosts
systemctl restart systemd-logind.service
reboot
hostname
ls -
apt update
apt upgrade -y
vi /etc/apt/sources.list
clear
sudo sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
apt full-upgrade
reboot
ls -l
cd Material_Adicional_TPVMCA/
ls -l
lsblk
fdisk /dev/sdb
lsblk
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
cat /proc/partitions  > /opt/particion
ls -l /opt/particion 
cat /opt/particion 
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk /dev/sdc
mkdir /www_dir
mkdir /backup_dir
ls -ld /www_dir /backup_dir/
mount /dev/sdc1 /www_dir/
mount /dev/sdc2 /backup_dir/
cp index.php /www_dir/
cp logo.png /www_dir/
chmod 644 /www_dir/index.php /www_dir/logo.png 
df -h | grep -E '/www_dir|/backup_dir'
blkid /dev/sdc1 /dev/sdc2
vim /etc/fstab 
blkid /dev/sdc1 /dev/sdc2
clear
blkid /dev/sdc1 /dev/sdc2 >> /etc/fstab 
tail -n 2 /etc/fstab 
vim /etc/fstab 
mount -a
df -h | grep -E '/www_dir|/backup_dir'
clear
ls -l
ls -la /www_dir
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
apachectl configtest
vim /etc/apache2/apache2.conf 
apachectl configtest
systenctk restart apache2
systenctl restart apache2
systemctl restart apache2
curl -I http://localhost/index.php
blkid /dev/sdc1
df -h | grep /www_dir/
blkid /dev/sdc2
df -h | grep /backup_dir/
reboot
df -h | grep -E '/www_dir|/backup_dir'
ls -la /www_dir/
systemctl status apache2
ls -l /proc/partitions 
ls -l /opt/particion 
cat /opt/particion 
mkdir -p /opt/scripts
vim /opt/scripts/backup_full.sh
clear
reboot
exit
cd /opt/
cd scripts/
ls -l
vim backup_full.sh
ls -l
vim backup_full.sh
cat backup_full.sh
vim backup_full.sh
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
crontab -e
ls -l
set -e
vim /opt/scripts/backup_full.sh
ls -l
reboot
cat /etc/hostname
vim /etc/hostname
cat /etc/hostname
cat /etc/hosts
vim /etc/hosts
vim /etc/apt/resources.list
vim /etc/apt/resources.list
cd /etc/
cd apt
ls -l
vm sources.list
vim sources.list
cd ..
cd ..
ls -l
cd home/
ls -l
cd compartido/
ls -l
reboot
ls -l
systemctl status ssh
ssh-keygen
cat /root/.ssh/id_rsa.pub 
scp /root/.ssh/id_rsa.pub  home@192.168.56.1
scp /root/.ssh/id_rsa.pub  home@192.168.56.1:/Users/home/.ssh/
scp /root/.ssh/id_rsa.pub  home@192.168.56.1:/Users/Home/.ssh/
vim /etc/ssh/sshd_config
systemctl restart sh
systemctl restart ssh
i'p
ip
ip -a
cat /etc/network/interfaces
clear
ls -l
dpkg -l | grep apache2
systemctl status apache2
php -v
mysql -u root -p
cat /etc/network/interfaces
cd /opt/
ls -l
cd particion
cat particion 
mkdir paricion
ls -l
rm -rf paricion/
mkdir particion
cd ..
ls /opt
sudo touch /opt/particion
cat /proc/patitions >> /opt/particion
crontab -e
clear
ls -l
reboot
