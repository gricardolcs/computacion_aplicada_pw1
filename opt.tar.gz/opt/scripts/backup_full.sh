#!/bin/bash

set -e

mostrar_ayuda() {
   echo "Uso: $0 <origen> <destino>"
   echo "Ejemplo_ $0 /var/log /backup_dir"
   echo ""
   echo "Opciones:"
   echo " -help     Muestra este mensaje de ayuda"
   exit 0		

}

if [ "$1" == "-help" ]; then
  mostrar_ayuda


if [ $# -ne 2 ] then
   echo "Error: Argumentos insuficientes"
   mostrar_ayuda
fi


ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ]; then
   echo "Error : el directorio de origen '$ORIGEN' no existe"
   exit 1
fi

if [ ! -d "$DESTINO"  ]; then
   echo "Error: el directorio de destino '$DESTINO' no existe"
fi

NOMBRE_BASE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)

NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
RUTA_DESTINO="${DESTINO}/${NOMBRE_ARCHIVO}"

echo "Iniciando respaldo de '$ORIGEN' en '$RUTA_DESTINO'..."
tar -czf "$RUTA_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE" 2>/dev/null

if [ $? -eq 0 ]; then
   echo "Respaldo completado con exito: $RUTA_DESTINO"
else
   echo "Error al crear el respaldo"
   exit 1
fi
