#!/bin/bash

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo "Genera <nombre>_bkp_YYYYMMDD.tar.gz con el contenido de <origen> dentro de <destino>."
    echo ""
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

esta_en_fstab() {
    awk '$1 !~ /^#/ {print $2}' /etc/fstab | grep -qx "$1"
}

if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: se esperaban 2 argumentos (origen y destino)" >&2
    mostrar_ayuda
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen '$ORIGEN' no existe o no es un directorio" >&2
    exit 1
fi

if esta_en_fstab "$ORIGEN" && ! mountpoint -q "$ORIGEN"; then
    echo "Error: el origen '$ORIGEN' está en /etc/fstab pero no está montado" >&2
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino '$DESTINO' no existe o no es un directorio" >&2
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino '$DESTINO' no es un sistema de archivos montado" >&2
    exit 1
fi

if [ ! -w "$DESTINO" ]; then
    echo "Error: no hay permisos de escritura en '$DESTINO'" >&2
    exit 1
fi

NOMBRE_BASE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
RUTA_DESTINO="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup de '$ORIGEN' en '$RUTA_DESTINO'..."

# tar devuelve 1 si algún archivo cambió mientras se leía (normal en /var/log)
tar -czf "$RUTA_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"
rc=$?
if [ $rc -gt 1 ]; then
    echo "Error al crear el backup (tar salió con código $rc)" >&2
    exit 1
fi

echo "Backup completado: $RUTA_DESTINO"
